﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Electronic
{
    namespace Sony
    {
        class XpediaZ
        {
        }
    }
    namespace Samsung
    {
        class GalaxyS21
        {

        }
        class GalaxyS20
        {

        }
    }
    class Tivi
    {

    }
}
